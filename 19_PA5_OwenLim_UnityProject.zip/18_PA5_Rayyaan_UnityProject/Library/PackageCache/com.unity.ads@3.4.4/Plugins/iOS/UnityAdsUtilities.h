const char * UnityAdsCopyString(const char * string);

/**
 * Returns the size of an Il2CppString
 */
size_t Il2CppStringLen(const ushort* str);

/**
 * Converts an ushort string to an NSString
 */
NSString* NSStringFromIl2CppString(const ushort* str);
