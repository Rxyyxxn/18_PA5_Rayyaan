﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    public int points;
    public Text Score;

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Score.text = ("Coins Collected: " + points);
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if (points == 4)
        {
            SceneManager.LoadScene("GamePlay_Level2");
        }
        if (points == 9)
        {
            SceneManager.LoadScene("GameWin");
        }

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "coins")
        {
            Debug.Log("hit");
            Destroy(other.gameObject);
            points++;
        }
        if (other.gameObject.tag == "Finish")
        {
            SceneManager.LoadScene("GameLoose");
        }
    }
}
